
function setup(){
  createCanvas(windowWidth,windowHeight);
  background('#FFFFFF');
}

function draw(){
  background('#FFFFFF');
  fill('#111111');
  lineDrawKey();
  shapeCopiesKey();
}
