
function drawType(){
  fill(255,0,0);
  noStroke();
  if(mouseX != pmouseX){
    text("hello world", 0, 0);
  }
}
