
function typePositionStart(){
  textSize(width/10);
  textAlign(CENTER);
  if(moveX < 300){
    moveX+=4;
  }
  text("hello world", moveX, height/2);
}
