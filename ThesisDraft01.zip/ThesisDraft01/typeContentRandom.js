
function typeContentRandom(){
  textSize(width/10);
  textAlign(CENTER);
  randomNum = random(0,10);
  if(randomNum > 5){
    text("square",width/2,height/2);
  } else{
    text("circle",width/2,height/2);
  }
}
