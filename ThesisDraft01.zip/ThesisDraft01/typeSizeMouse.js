
function typeSizeMouse(){
  textSize(width/10);
  textAlign(CENTER);
  textSize(20+mouseX);
  text("hello world", width/2, height/2);
}
