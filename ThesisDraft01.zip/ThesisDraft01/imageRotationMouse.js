
function imageRotationMouse(){
  translate(width/2,0);
  rotate(mouseY*0.025);
  image(pImg1, 0,0,200,200);
}
