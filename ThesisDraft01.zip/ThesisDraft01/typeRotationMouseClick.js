
function typeRotationMouseClick(){
  textSize(width/10);
  textAlign(CENTER);
  if(mouseIsPressed == true){
    genCount+=0.1;
  }
  translate(width/2,height/2);
  push();
  rotate(genCount);
  text("hello world", 0, 0);
  // rect(0,0,200,200);
  pop();
}
