
function typeRotationRandom(){
  textSize(width/10);
  textAlign(CENTER);
  translate(width/2,height/2);
  if((frameCount*0.1)%2 == 1){
    genCount +=random(0,360);
  }
  rotate(genCount);
  text("hello world", 0, 0);
}
