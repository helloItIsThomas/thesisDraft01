
function typeContentKey(){
  textSize(width/10);
  textAlign(CENTER);
  if(keyIsPressed === true){
    text("square",width/2,height/2);
  } else{
    text("circle",width/2,height/2);
  }
}
