
function typeDrawStart(){
  textSize(width/10);
  textAlign(CENTER);
  text("hello world", width/2, height/2);
}
