
function typeDrawMouseClick(){
  textSize(width/10);
  textAlign(CENTER);
  if(mouseIsPressed == true){
    text("hello world", width/2, height/2);
  }
}
