
function imageDrawMouse(){
  if(mouseIsPressed){
    image(pImg1, width/2,0,200,200);
  }
}
