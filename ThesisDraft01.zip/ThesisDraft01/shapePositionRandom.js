

function shapePositionRandom(){
  noStroke();
  circle(random(width),random(height), 50);
}
