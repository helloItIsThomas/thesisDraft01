
function drawLine(){
  stroke(255,0,0);
  strokeWeight(5);
  line(50, 50, 200, 50);
}
