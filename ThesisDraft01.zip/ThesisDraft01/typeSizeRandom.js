
function typeSizeRandom(){
  textSize(width/10);
  textAlign(CENTER);
  genCount = random(0,500);
  textSize(20+genCount);
  text("hello world", width/2, height/2);
}
