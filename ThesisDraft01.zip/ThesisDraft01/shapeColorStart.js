
function shapeColorStart(){
  fill(color1);
  if(frameCount > 10){
    fill(color2);
  }
  circle(windowWidth*0.5,0,windowWidth*0.25);
}
