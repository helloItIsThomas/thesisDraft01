
function typeDrawKey(){
  textSize(width/10);
  textAlign(CENTER);
  if(keyIsPressed == true){
    text("circle",width/2,height/2);
  }
}
