
function lineSizeKey(){
  stroke(color1);
  translate(width/2,0);
  line(0,0,(keyRight*10)-(keyLeft*10),0);
  line(0,0,0,(keyDown*10)-(keyUp*10));
}
