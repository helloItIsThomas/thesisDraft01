
function imageContentMouse(){
  if(mouseX > width/2){
    image(pImg2, width/2,0,200,200);
  } else{
    image(pImg1, width/2,0,200,200);
  }
}
