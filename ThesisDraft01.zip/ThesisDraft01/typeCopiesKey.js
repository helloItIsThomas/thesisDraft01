
function typeCopiesKey(){
  textSize(width/10);
  textAlign(CENTER);
  text("circle",width/2,height/2);
  if(keyIsPressed == true){
    genCount++;
  }
  for(let x=0; x<genCount; x++){
    text("circle",x*100,height/2);
  }
}
