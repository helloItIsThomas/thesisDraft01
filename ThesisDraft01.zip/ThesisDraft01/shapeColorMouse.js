
function shapeColorMouse(){
  if(mouseX != pmouseX){
    fill(color2);
  } else{
    fill(color1);
  }
  circle(windowWidth*0.5,0,windowWidth*0.25);
}
