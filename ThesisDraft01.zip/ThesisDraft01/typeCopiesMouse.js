let genCount2 = 0;

function typeCopiesMouse(){
  textSize(width/10);
  textAlign(CENTER);
  text("circle",width/2,height/2);
  if(mouseX != pmouseX || mouseY != pmouseY){
    genCount2++;
  }
  for(let x=0; x<genCount2; x++){
    text("circle",x*100,height/2);
  }
}
