
function shapePositionMouse(){
  translate(-1*marginW,-1*((menuH + marginH)+(height/2)));
  noStroke();
  circle(mouseX,mouseY,windowWidth*0.25);
}
