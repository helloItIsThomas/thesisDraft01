
function lineDrawStart(){
  stroke(color1);
  if(frameCount > 5){
    line(width/2-300,0,width/2+300,0);
  }
}
