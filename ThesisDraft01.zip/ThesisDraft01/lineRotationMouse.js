
function lineRotationMouse(){
  stroke(color1);
  translate(width/2,0);
  rotate(mouseY*0.025);
  line(0,0,200,0);
}
