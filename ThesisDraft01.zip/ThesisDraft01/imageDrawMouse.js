
function imageDrawMouse(){
  if(mouseX != pmouseX){
    image(pImg1, width/2,0,200,200);
  }
}
