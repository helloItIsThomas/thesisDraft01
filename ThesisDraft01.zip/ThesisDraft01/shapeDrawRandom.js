

function typeDrawRandom(){
  let myRandomNum = int(random(10));
  noStroke();
  if(myRandomNum == 3){
    circle(windowWidth*0.5,0,windowWidth*0.25);
  }
}
