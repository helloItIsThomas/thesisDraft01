
function imageDrawRandom(){
  randomNum = random(0,10);
  if(randomNum > 9){
    image(pImg2, width/2,0,200,200);
  }
}
