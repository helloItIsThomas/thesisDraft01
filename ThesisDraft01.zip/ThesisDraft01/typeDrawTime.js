
function typeDrawTime(){
  textSize(width/10);
  textAlign(CENTER);
  if(frameCount > 100){
    text("hello world", width/2, height/2);
  }
}
