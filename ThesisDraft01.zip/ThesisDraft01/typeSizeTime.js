
function typeSizeTime(){
  textSize(width/10);
  textAlign(CENTER);
  if(frameCount > 100){
    if(genCount < width/8){
      genCount+=4;
    }
  }
  textSize(20+genCount);
  text("hello world", width/2, height/2);
}
