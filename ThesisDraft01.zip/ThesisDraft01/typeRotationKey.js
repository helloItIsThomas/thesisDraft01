
function typeRotationKey(){
  textSize(width/10);
  textAlign(CENTER);
  translate(width/2,height/2);
  rotate(keyRight*QUARTER_PI*0.5);
  rotate(-1*(keyLeft*QUARTER_PI*0.5));
  // rect(0,0,200,150);
  text("hello world", moveX, 0);
}
