
function lineSizeMouse(){
  stroke(color1);
  translate(width/2,0);
  line(0,0,mouseX,0);
  line(0,0,0,mouseY);
}
