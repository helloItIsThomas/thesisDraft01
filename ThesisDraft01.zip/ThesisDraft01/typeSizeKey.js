
function typeSizeKey(){
  textSize(width/10);
  textAlign(CENTER);
  textSize(20+(keyUp*10)-(keyDown*10));
  text("hello world", width/2, height/2);
}
