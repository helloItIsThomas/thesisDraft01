
function imagePositionKey(){
  noStroke();
  translate(width/2,0);
  image(pImg1, keyRight*10-keyLeft*10,keyDown*10-keyUp*10,200,200);
}
