
function shapeSizeMouseClick(){
  if(mouseIsPressed == true){
    genCount++;
  }
  circle(width/2,height/2,20+genCount);
}
