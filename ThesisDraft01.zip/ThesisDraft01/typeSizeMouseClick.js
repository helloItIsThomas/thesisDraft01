
function typeSizeMouseClick(){
  textSize(width/10);
  textAlign(CENTER);
  if(mouseIsPressed == true){
    genCount++;
  }
  textSize(20+genCount);
  text("hello world", width/2, height/2);
}
