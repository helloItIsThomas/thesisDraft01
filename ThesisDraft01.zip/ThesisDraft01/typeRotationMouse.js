
function typeRotationMouse(){
  textSize(width/10);
  textAlign(CENTER);
  translate(width/2,height/2);
  rotate(mouseY*0.025);
  // line(0,0,200,0);
  text("hello world", 0, 0);
}
