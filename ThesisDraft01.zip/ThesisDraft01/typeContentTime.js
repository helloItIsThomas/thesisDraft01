
function typeContentTime(){
  textSize(width/10);
  textAlign(CENTER);
  if(frameCount > 100){
    text("square",width/2,height/2);
  } else{
    text("circle",width/2,height/2);
  }
}
