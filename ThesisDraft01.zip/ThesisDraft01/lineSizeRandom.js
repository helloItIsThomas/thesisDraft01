
function lineSizeRandom(){
  stroke(color1);
  translate(width/2,0);
  genCount = random(0,500);
  line(0,50,genCount,genCount);
}
