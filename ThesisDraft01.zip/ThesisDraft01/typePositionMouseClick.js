
function typePositionMouseClick(){
  textSize(width/10);
  textAlign(CENTER);
  if(mouseIsPressed ==  true){
    xPos = mouseX;
    yPos = mouseY;
  }
  text("hello world", xPos, yPos);
}
