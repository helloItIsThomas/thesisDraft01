
function typePositionTime(){
  textSize(width/10);
  textAlign(CENTER);
  if(frameCount > 100){
    if(frameCount < 200){
      moveX+=4;
    }
  }
  text("hello world", moveX, height/2);
}
