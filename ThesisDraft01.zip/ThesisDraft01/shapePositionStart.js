
function shapePositionStart(){
  noStroke();
  if(moveX < 900){
    moveX+=4;
  }
  circle(moveX,0,200);
}
