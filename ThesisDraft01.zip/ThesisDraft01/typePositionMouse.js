
function typePositionMouse(){
  textSize(width/10);
  textAlign(CENTER);
  noStroke();
  text("hello world", mouseX, mouseY);
}
