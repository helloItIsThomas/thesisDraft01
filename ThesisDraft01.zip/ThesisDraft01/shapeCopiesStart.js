
function shapeCopiesStart(){
  genCount+=0.1;
  for(let x=0; x<genCount; x++){
    circle(x*20,0,20);
  }
}
