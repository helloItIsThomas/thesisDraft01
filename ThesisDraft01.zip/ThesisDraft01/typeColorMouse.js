
function typeColorMouse(){
  if(mouseX != pmouseX){
    fill(color2);
  } else{
    fill(color1);
  }
  textSize(width/10);
  textAlign(CENTER);
  text("circle",width/2,height/2);
}
