
function typeColorStart(){
  fill(color1);
  if(frameCount > 10){
    fill(color2);
  }
  textSize(width/10);
  textAlign(CENTER);
  text("circle",width/2,height/2);
}
