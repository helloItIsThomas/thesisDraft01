
function typeDrawRandom2(){
  textSize(width/10);
  textAlign(CENTER);
  randomNum = random(0,10);
  if(randomNum > 9){
    text("hello world", width/2, height/2);
  }
}
