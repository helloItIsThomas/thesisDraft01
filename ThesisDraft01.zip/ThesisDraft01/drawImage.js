
function drawImage(){
  image(pImg1, 50,50,200,200);
}
