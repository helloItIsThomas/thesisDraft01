
function lineDrawMouseClick(){
  stroke(color1);
  if(mouseIsPressed == true){
    line(width/2-300,0,width/2+300,0);
  }
}
