

function shapeDrawStart(){
  noStroke();
  circle(windowWidth*0.5,0,windowWidth*0.25);
}
