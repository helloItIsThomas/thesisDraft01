
function typePositionKey(){
  textSize(width/10);
  textAlign(CENTER);
  translate(width/2,height/2);
  text("hello world", keyRight*10-keyLeft*10, keyDown*10-keyUp*10);
}
