
function typeColorTime(){
  fill(color1);
  if(frameCount > 100){
    fill(color2);
  }
  textSize(width/10);
  textAlign(CENTER);
  text("circle",width/2,height/2);
}
