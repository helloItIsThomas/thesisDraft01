
function imageSizeRandom(){
  translate(width/2,0);
  genCount = random(0,500);
  image(pImg1, 0,50,genCount,genCount);
}
