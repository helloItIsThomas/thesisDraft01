
function imageSizeMouse(){
  translate(width/2,0);
  image(pImg1, 0, 50, mouseX,mouseX);
}
