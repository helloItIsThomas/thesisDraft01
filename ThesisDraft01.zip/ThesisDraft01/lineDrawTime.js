
function lineDrawTime(){
  stroke(color1);
  if(frameCount > 100){
    line(width/2-300,0,width/2+300,0);
  }
}
