

function shapeDrawTime(){
  noStroke();
  if(frameCount > 100){
    circle(windowWidth*0.5,0,windowWidth*0.25);
  }
}
