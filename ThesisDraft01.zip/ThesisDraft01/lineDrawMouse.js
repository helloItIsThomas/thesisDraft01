
function lineDrawMouse(){
  stroke(color1);
  if(mouseX != pmouseX){
    line(width/2-300,0,width/2+300,0);
  }
}
