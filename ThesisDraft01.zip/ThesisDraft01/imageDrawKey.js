
function imageDrawKey(){
  if(keyIsPressed == true){
    image(pImg1, width/2,0,200,200);
  }
}
