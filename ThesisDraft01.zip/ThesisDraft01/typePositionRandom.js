
function typePositionRandom(){
  textSize(width/10);
  textAlign(CENTER);
  noStroke();
  randomNum = random(0,width);
  randomNum2 = random(0,height);
  text("hello world", randomNum, randomNum2);
}
