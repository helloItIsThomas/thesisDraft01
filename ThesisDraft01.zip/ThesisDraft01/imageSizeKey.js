
function imageSizeKey(){
  translate(width/2,0);
  image(pImg1, 0,50,(keyRight*10)-(keyLeft*10),(keyRight*10)-(keyLeft*10));
}
