
function imageDrawStart(){
  image(pImg2, width/2,0,200,200);
}
