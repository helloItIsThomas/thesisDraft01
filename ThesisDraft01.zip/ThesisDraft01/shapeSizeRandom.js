
function shapeSizeRandom(){
  genCount = random(0,500);
  circle(width/2,height/2,genCount);
}
