
function typeContentMouse(){
  textSize(width/10);
  textAlign(CENTER);
  if(mouseX > width/2){
    text("square",width/2,height/2);
  } else{
    text("circle",width/2,height/2);
  }
}
