
function typeRotationStart(){
  textSize(width/10);
  textAlign(CENTER);
  translate(width/2,height/2);
  genCount += 0.01;
  rotate(genCount);
  text("hello world", 0, 0);
}
